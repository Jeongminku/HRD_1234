package DTO;

public class Result {
	int songno;
	String songtitle;
	String singer;
	String yaddress;
	int gubun;
	

	public int getGubun() {
		return gubun;
	}
	public void setGubun(int gubun) {
		this.gubun = gubun;
	}
	public String getYaddress() {
		return yaddress;
	}
	public void setYaddress(String yaddress) {
		this.yaddress = yaddress;
	}
	public int getSongno() {
		return songno;
	}
	public void setSongno(int songno) {
		this.songno = songno;
	}
	public String getSongtitle() {
		return songtitle;
	}
	public void setSongtitle(String songtitle) {
		this.songtitle = songtitle;
	}
	public String getSinger() {
		return singer;
	}
	public void setSinger(String singer) {
		this.singer = singer;
	}
	
	
}
